import test from 'node:test';
import assert from 'node:assert/strict';
import {ReceiptStore,bytes} from '../core.mjs';

function rng(seed){return()=>{seed=(seed*1664525+1013904223)>>>0;return seed/0x100000000;};}

test('50 deterministic chaotic sessions preserve revision, readiness and receipt invariants',async()=>{
  for(let seed=1;seed<=50;seed++){
    const random=rng(seed),store=new ReceiptStore(),known=new Map(),ids=['brief','budget','approval'];
    for(let step=0;step<120;step++){
      const before=store.snapshot(),action=Math.floor(random()*5),id=ids[Math.floor(random()*ids.length)];
      try{
        if(action<=1){
          const value=`seed=${seed};step=${step};nonce=${random()}`;
          store.attach(id,`${id}-${step}.txt`,bytes(value),before.revision,'stress');
        }else if(action===2){
          store.require(id,random()>.45,before.revision);
        }else if(action===3){
          const receipt=await store.build(before.revision,'stress');
          const zip=store.packageBytes(receipt.id);
          if(!known.has(receipt.id))known.set(receipt.id,{revision:receipt.revision,sha256:receipt.sha256,zip});
          else assert.deepEqual(zip,known.get(receipt.id).zip,'idempotent receipt bytes changed');
        }else{
          const staleRevision=Math.max(0,before.revision-1);
          await assert.rejects(store.build(staleRevision,'stress'),/REVISION_CONFLICT/);
        }
      }catch(error){
        assert.match(error.message,/MISSING_DOCUMENTS|At least one document|REVISION_CONFLICT/);
      }
      const state=store.snapshot(),required=state.documents.filter(d=>d.required);
      assert.ok(required.length>=1);
      assert.equal(state.ready,required.every(d=>d.present));
      assert.deepEqual(state.missing,required.filter(d=>!d.present).map(d=>d.id));
      for(const receipt of state.packages){
        const original=known.get(receipt.id);assert.ok(original);
        assert.equal(receipt.sha256,original.sha256);
        assert.deepEqual(store.packageBytes(receipt.id),original.zip);
        assert.equal(receipt.status,receipt.revision===state.revision?'current':'stale');
        assert.equal(receipt.downloadStatus,'not_confirmed');
      }
      assert.equal(state.packages.filter(p=>p.status==='current').length<=1,true);
    }
  }
});

test('agent-like race cannot turn an obsolete build into a current receipt',async()=>{
  let releaseFirst, calls=0;
  const hash=async data=>{if(++calls===1)await new Promise(resolve=>releaseFirst=resolve);return crypto.subtle.digest('SHA-256',data).then(b=>[...new Uint8Array(b)].map(v=>v.toString(16).padStart(2,'0')).join(''));};
  const store=new ReceiptStore({hash});store.attach('approval','approval.txt',bytes('one'),1);
  const p1=store.build(2,'webmcp');
  await new Promise(resolve=>setImmediate(resolve));
  store.attach('approval','approval.txt',bytes('two'),2);
  const p2=store.build(3,'webmcp');
  const receipt=await p2;
  releaseFirst();
  await assert.rejects(p1,/REVISION_CONFLICT/);
  assert.equal(receipt.status,'current');assert.equal(receipt.revision,3);
  assert.equal(store.snapshot().packages.length,1);
});
