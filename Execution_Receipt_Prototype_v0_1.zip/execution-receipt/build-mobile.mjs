import { readFile, writeFile } from 'node:fs/promises';

const root = new URL('./', import.meta.url);
const [html, css, coreSource, webmcpSource, appSource] = await Promise.all([
  readFile(new URL('index.html', root), 'utf8'),
  readFile(new URL('style.css', root), 'utf8'),
  readFile(new URL('core.mjs', root), 'utf8'),
  readFile(new URL('webmcp.mjs', root), 'utf8'),
  readFile(new URL('app.mjs', root), 'utf8'),
]);

const stripModuleSyntax = source => source
  .replace(/^import .*?;\s*$/gm, '')
  .replace(/\bexport\s+(?=(?:async\s+)?function\b|class\b|const\b|let\b|var\b)/g, '');

const script = [coreSource, webmcpSource, appSource]
  .map(stripModuleSyntax)
  .join('\n\n')
  .replaceAll('</script', '<\\/script');

let output = html
  .replace('<link rel="stylesheet" href="style.css">', `<style>\n${css}\n</style>`)
  .replace('<script type="module" src="app.mjs"></script>', `<script type="module">\n${script}\n</script>`)
  .replace('LOCAL PROTOTYPE · 0.1', 'MOBILE REVIEW · 0.1')
  .replace('Session-only workspace. Documents stay in this browser tab; refreshing clears the workspace. Download your package before leaving. Demo content is synthetic.', 'Single-file mobile review. Documents stay in this browser tab; refreshing clears the workspace. Download your package before leaving. Demo content is synthetic. WebMCP requires a supported secure browser; manual mode remains usable.');

if (/(?:src|href)="(?:app\.mjs|core\.mjs|webmcp\.mjs|style\.css)"/.test(output)) {
  throw new Error('Standalone build still contains local asset references.');
}

await writeFile(new URL('../Execution_Receipt_Mobile_Review_v0_1.html', root), output);
console.log('Built Execution_Receipt_Mobile_Review_v0_1.html');
