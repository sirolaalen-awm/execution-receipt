const enc = new TextEncoder();
export const bytes = value => enc.encode(value);
export async function sha256(data) {
  return [...new Uint8Array(await crypto.subtle.digest('SHA-256', data))].map(v => v.toString(16).padStart(2, '0')).join('');
}
export function crc32(data) {
  let crc = 0xffffffff;
  for (const byte of data) { crc ^= byte; for (let k=0;k<8;k++) crc = (crc >>> 1) ^ (0xedb88320 & -(crc & 1)); }
  return (crc ^ 0xffffffff) >>> 0;
}
// ZIP STORE, UTF-8 names, fixed DOS timestamp. No dependencies or compression.
export function makeZip(entries) {
  const local=[], central=[]; let offset=0;
  for (const {name,data} of entries) {
    const n=bytes(name), crc=crc32(data);
    const h=new Uint8Array(30+n.length), v=new DataView(h.buffer);
    v.setUint32(0,0x04034b50,true);v.setUint16(4,20,true);v.setUint16(6,0x800,true);v.setUint16(12,33,true);
    v.setUint32(14,crc,true);v.setUint32(18,data.length,true);v.setUint32(22,data.length,true);v.setUint16(26,n.length,true);h.set(n,30);
    const c=new Uint8Array(46+n.length), w=new DataView(c.buffer);
    w.setUint32(0,0x02014b50,true);w.setUint16(4,20,true);w.setUint16(6,20,true);w.setUint16(8,0x800,true);w.setUint16(14,33,true);
    w.setUint32(16,crc,true);w.setUint32(20,data.length,true);w.setUint32(24,data.length,true);w.setUint16(28,n.length,true);w.setUint32(42,offset,true);c.set(n,46);
    local.push(h,data);central.push(c);offset+=h.length+data.length;
  }
  const size=central.reduce((sum,x)=>sum+x.length,0), end=new Uint8Array(22), v=new DataView(end.buffer);
  v.setUint32(0,0x06054b50,true);v.setUint16(8,entries.length,true);v.setUint16(10,entries.length,true);v.setUint32(12,size,true);v.setUint32(16,offset,true);
  const out=new Uint8Array(offset+size+22);let at=0;
  for(const part of [...local,...central,end]){out.set(part,at);at+=part.length;} return out;
}
export class ReceiptStore {
  #docs; #revision=1; #log=[]; #packages=[]; #sequence=0; #clock; #hash;
  constructor({clock=()=>new Date().toISOString(),hash=sha256}={}) {
    this.#clock=clock;this.#hash=hash;
    this.#docs=[
      {id:'brief',label:'Project brief',required:true,name:'project-brief.txt',data:bytes('Execution Receipt — synthetic demo project brief.\n'),version:1},
      {id:'budget',label:'Budget',required:true,name:'budget.csv',data:bytes('item,amount\nDesign,250\nDevelopment,750\n'),version:1},
      {id:'approval',label:'Approval document',required:true,name:null,data:null,version:0}
    ]; this.#event('session_started','system','Synthetic documents loaded. Approval document is missing.');
  }
  #event(action,actor,detail){this.#log.push({sequence:++this.#sequence,time:this.#clock(),action,actor,detail,revision:this.#revision});}
  #check(revision){if(!Number.isInteger(revision)||revision!==this.#revision)throw new Error('REVISION_CONFLICT: read the current case and retry.');}
  #doc(id){const d=this.#docs.find(x=>x.id===id);if(!d)throw new Error('UNKNOWN_DOCUMENT');return d;}
  snapshot(){
    const docs=this.#docs.map(({data,...d})=>({...d,present:data!==null,bytes:data?.length??0}));
    const missing=docs.filter(d=>d.required&&!d.present).map(d=>d.id);
    return {revision:this.#revision,documents:docs,missing,ready:missing.length===0&&docs.some(d=>d.required),packages:this.#packages.map(p=>this.#receipt(p)),events:structuredClone(this.#log)};
  }
  #receipt(p){return {...structuredClone(p.receipt),status:p.revision===this.#revision?'current':'stale',currentRevision:this.#revision};}
  attach(id,name,data,expectedRevision,actor='human'){
    this.#check(expectedRevision);const d=this.#doc(id);
    if(typeof name!=='string'||!name.trim()||name.length>120||/[\\/\x00-\x1f]/.test(name)||name==='.'||name==='..')throw new Error('INVALID_FILENAME');
    if(!(data instanceof Uint8Array)||data.length===0||data.length>2*1024*1024)throw new Error('INVALID_CONTENT: document must contain 1 byte to 2 MiB.');
    if(d.name===name&&d.data?.length===data.length&&d.data.every((x,i)=>x===data[i]))return this.snapshot();
    d.name=name;d.data=data.slice();d.version++;this.#revision++;this.#event('document_attached',actor,`${id}: ${name}, version ${d.version}`);return this.snapshot();
  }
  require(id,required,expectedRevision){
    this.#check(expectedRevision);const d=this.#doc(id);if(typeof required!=='boolean')throw new Error('INVALID_REQUIRED');
    if(!required&&d.required&&this.#docs.filter(x=>x.required).length===1)throw new Error('At least one document must be required.');
    if(d.required===required)return this.snapshot();d.required=required;this.#revision++;this.#event('requirement_changed','human',`${id}: required=${required}`);return this.snapshot();
  }
  async build(expectedRevision,actor='human',signal){
    this.#check(expectedRevision);if(signal?.aborted)throw new Error('CANCELLED');
    const state=this.snapshot();
    if(!state.ready){this.#event('build_blocked',actor,`Missing: ${state.missing.join(', ')}`);throw new Error(`MISSING_DOCUMENTS: ${state.missing.join(', ')}`);}
    const existing=this.#packages.find(p=>p.revision===this.#revision);if(existing)return this.#receipt(existing);
    const revision=this.#revision, selected=this.#docs.filter(d=>d.required).map(d=>({...d,data:d.data.slice()}));
    const documents=await Promise.all(selected.map(async d=>({id:d.id,path:`documents/${d.id}/${d.name}`,name:d.name,version:d.version,bytes:d.data.length,sha256:await this.#hash(d.data)})));
    const manifest={format:'execution-receipt/1',revision,createdAt:this.#clock(),documents,scope:'Confirms package contents, not document truth, legal approval, submission or download.'};
    const zip=makeZip([...selected.map((d,i)=>({name:documents[i].path,data:d.data})),{name:'manifest.json',data:bytes(JSON.stringify(manifest,null,2))}]);
    const digest=await this.#hash(zip);
    if(signal?.aborted)throw new Error('CANCELLED');
    this.#check(revision); // No commit if source changed while hashing.
    const concurrent=this.#packages.find(p=>p.revision===revision);if(concurrent)return this.#receipt(concurrent);
    const id=`receipt-${this.#packages.length+1}`;
    const receipt={id,revision,createdAt:manifest.createdAt,filename:`execution-package-r${revision}.zip`,bytes:zip.length,sha256:digest,manifest,downloadStatus:'not_confirmed'};
    this.#packages.push({revision,receipt,zip});this.#event('package_created',actor,`${id}: ${zip.length} bytes; SHA-256 ${digest}`);return this.#receipt(this.#packages.at(-1));
  }
  receipt(id){const p=this.#packages.find(p=>p.receipt.id===id);if(!p)throw new Error('UNKNOWN_RECEIPT');return this.#receipt(p);}
  packageBytes(id){const p=this.#packages.find(p=>p.receipt.id===id);if(!p)throw new Error('UNKNOWN_RECEIPT');return p.zip.slice();}
  downloadRequested(id){this.receipt(id);this.#event('download_requested','human',`${id}: request only; saving to disk is not confirmed.`);}
}
