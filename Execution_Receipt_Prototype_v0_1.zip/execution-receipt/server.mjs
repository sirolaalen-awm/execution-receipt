import http from 'node:http';
import {readFile} from 'node:fs/promises';
const root=new URL('./',import.meta.url);
const allowed=new Map([['/','index.html'],['/index.html','index.html'],['/style.css','style.css'],['/app.mjs','app.mjs'],['/core.mjs','core.mjs'],['/webmcp.mjs','webmcp.mjs']]);
const port=Number(process.env.RECEIPT_PORT||8080);
const host=process.env.RECEIPT_HOST||'127.0.0.1';
http.createServer(async(req,res)=>{
  if(!['GET','HEAD'].includes(req.method)){res.writeHead(405);return res.end();}
  const path=new URL(req.url,'http://localhost').pathname,file=allowed.get(path);
  if(!file){res.writeHead(404);return res.end('Not found');}
  try{const data=await readFile(new URL(file,root));res.writeHead(200,{'Content-Type':file.endsWith('.html')?'text/html; charset=utf-8':file.endsWith('.css')?'text/css; charset=utf-8':'text/javascript; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'none'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'"});res.end(req.method==='HEAD'?undefined:data);}catch{res.writeHead(500);res.end('File unavailable');}
}).listen(port,host,()=>console.log(`Execution Receipt: http://${host}:${port}`));
