import {ReceiptStore,bytes} from './core.mjs';
import {registerWebMCP} from './webmcp.mjs';
const store=new ReceiptStore(), $=id=>document.getElementById(id);
const el=(tag,text,cls)=>{const e=document.createElement(tag);if(text!==undefined)e.textContent=text;if(cls)e.className=cls;return e;};
let building=false;
function message(text){$('message').textContent=text;}
function download(id,receiptOnly=false){
  const receipt=store.receipt(id), data=receiptOnly?JSON.stringify(receipt,null,2):store.packageBytes(id);
  const blob=new Blob([data],{type:receiptOnly?'application/json':'application/zip'}), url=URL.createObjectURL(blob);
  const a=el('a');a.href=url;a.download=receiptOnly?`${id}.json`:receipt.filename;document.body.append(a);a.click();a.remove();
  setTimeout(()=>URL.revokeObjectURL(url),30000);
  if(!receiptOnly)store.downloadRequested(id);message('Download requested. Saving to disk remains unconfirmed.');render();
}
function render(){
  const s=store.snapshot();$('revision').textContent=`REV ${String(s.revision).padStart(3,'0')}`;
  $('documents').replaceChildren();
  for(const d of s.documents){
    const row=el('div',undefined,'doc'), cb=el('input');cb.type='checkbox';cb.checked=d.required;cb.setAttribute('aria-label',`Require ${d.label}`);
    cb.onchange=()=>{try{store.require(d.id,cb.checked,s.revision);message('Requirements updated.');}catch(e){message(e.message);}render();};
    const info=el('div');info.append(el('strong',d.label),el('div',d.present?`${d.name} · v${d.version} · ${d.bytes.toLocaleString()} bytes`:'No document attached','meta'),el('span',d.present?'ATTACHED':d.required?'MISSING':'OPTIONAL',`badge ${d.present?'':'warn'}`));
    const label=el('label',d.present?'Replace file':'Attach file','upload'), input=el('input');input.type='file';input.setAttribute('aria-label',`Attach ${d.label}`);label.append(input);
    input.onchange=async()=>{const file=input.files[0];if(!file)return;try{if(file.size>2*1024*1024)throw new Error('Maximum file size is 2 MiB.');const data=new Uint8Array(await file.arrayBuffer());store.attach(d.id,file.name,data,s.revision);message('Document attached.');}catch(e){message(e.message);}render();};
    row.append(cb,info,label);$('documents').append(row);
  }
  const required=s.documents.filter(d=>d.required);$('readiness').replaceChildren(document.createTextNode(`${required.filter(d=>d.present).length}/${required.length} `),el('span','documents present'));
  $('reason').textContent=s.ready?'All required documents are present.':`Missing: ${s.documents.filter(d=>s.missing.includes(d.id)).map(d=>d.label).join(', ')}.`;
  $('build').disabled=building;$('build').textContent=building?'Creating actual ZIP bytes…':'Build package ↗';
  $('sample').disabled=s.documents.find(d=>d.id==='approval').present;
  $('receipts').replaceChildren();
  if(!s.packages.length)$('receipts').append(el('div','No package created yet. A successful build will produce downloadable ZIP bytes and a receipt.','empty'));
  for(const p of [...s.packages].reverse()){
    const row=el('article',undefined,'receipt'), top=el('div',undefined,'receipt-top'), title=el('div');
    title.append(el('strong',p.id),document.createTextNode('  '),el('span',p.status.toUpperCase(),`badge ${p.status==='stale'?'stale':''}`),el('p',`Revision ${p.revision} · ${p.bytes.toLocaleString()} ZIP bytes · ${p.createdAt}`,'small'));
    const actions=el('div',undefined,'receipt-actions');for(const [label,only] of [['Download ZIP',false],['Receipt JSON',true]]){const b=el('button',label,'secondary');b.onclick=()=>download(p.id,only);actions.append(b);}top.append(title,actions);
    row.append(top,el('code',`SHA-256 ${p.sha256}`,'digest'),el('p',p.status==='stale'?'Source changed. This preserved package no longer represents the current revision.':'Package bytes exist in this tab. Saving to disk: NOT CONFIRMED.','small'));
    const detail=el('details');detail.append(el('summary','Inspect manifest'),el('pre',JSON.stringify(p.manifest,null,2)));row.append(detail);$('receipts').append(row);
  }
  $('events').replaceChildren();for(const event of [...s.events].reverse()){
    const row=el('li'), time=el('time',event.time.slice(11,19));time.dateTime=event.time;
    row.append(time,el('span',event.actor.toUpperCase(),'mono'),el('span',`${event.action.replaceAll('_',' ')} — ${event.detail}`));$('events').append(row);
  }
  const calls=s.events.filter(e=>e.actor==='webmcp');if(calls.length)$('agent-note').textContent=`${calls.length} mutation event(s) via the WebMCP handler. This does not certify the calling agent's identity.`;
}
$('sample').onclick=()=>{try{store.attach('approval','sample-approval.txt',bytes('SYNTHETIC DEMO ONLY\nThis attachment demonstrates document presence. It is not a legal approval.\n'),store.snapshot().revision);message('Synthetic sample attached.');}catch(e){message(e.message);}render();};
$('build').onclick=async()=>{building=true;render();try{const r=await store.build(store.snapshot().revision);message(`Created ${r.filename}. ZIP bytes and receipt are available below.`);}catch(e){message(e.message);}finally{building=false;render();}};
render();
const registration=await registerWebMCP(document.modelContext,store,render);
$('connection').textContent=registration.status==='registered'?`WebMCP: ${registration.count} tools registered`:registration.status==='unavailable'?'WebMCP unavailable · manual mode':`WebMCP registration failed: ${registration.error}`;
