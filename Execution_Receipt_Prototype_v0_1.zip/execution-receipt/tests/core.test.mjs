import test from 'node:test';
import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {ReceiptStore,bytes,sha256,crc32} from '../core.mjs';
import {toolsFor,registerWebMCP} from '../webmcp.mjs';
const ready=()=>{const s=new ReceiptStore();s.attach('approval','approval.txt',bytes('Synthetic approval'),1);return s;};
function unzipStore(zip){
  const v=new DataView(zip.buffer,zip.byteOffset,zip.byteLength),out={};let at=0;
  while(v.getUint32(at,true)===0x04034b50){
    const size=v.getUint32(at+18,true), n=v.getUint16(at+26,true), extra=v.getUint16(at+28,true);
    const name=new TextDecoder().decode(zip.slice(at+30,at+30+n)),start=at+30+n+extra,data=zip.slice(start,start+size);
    assert.equal(crc32(data),v.getUint32(at+14,true));out[name]=data;at=start+size;
  }assert.equal(v.getUint32(at,true),0x02014b50);assert.equal(v.getUint32(zip.length-22,true),0x06054b50);return out;
}
test('initial state has one missing required document',()=>{assert.deepEqual(new ReceiptStore().snapshot().missing,['approval']);});
test('missing document blocks build and records real rejection',async()=>{const s=new ReceiptStore();await assert.rejects(s.build(1),/MISSING_DOCUMENTS/);assert.equal(s.snapshot().packages.length,0);assert.equal(s.snapshot().events.at(-1).action,'build_blocked');});
test('ZIP contains exact documents and manifest, hashes match bytes',async()=>{
  const s=ready(),r=await s.build(2),zip=s.packageBytes(r.id),entries=unzipStore(zip);
  assert.equal(await sha256(zip),r.sha256);assert.equal(Object.keys(entries).length,4);
  const manifest=JSON.parse(new TextDecoder().decode(entries['manifest.json']));assert.deepEqual(manifest,r.manifest);
  for(const d of manifest.documents){assert.equal(entries[d.path].length,d.bytes);assert.equal(await sha256(entries[d.path]),d.sha256);}
  assert.equal(r.status,'current');assert.equal(r.downloadStatus,'not_confirmed');
});
test('duplicate build is idempotent',async()=>{const s=ready(),a=await s.build(2),b=await s.build(2);assert.equal(a.id,b.id);assert.equal(s.snapshot().packages.length,1);});
test('concurrent builds create one receipt',async()=>{const s=ready(),r=await Promise.all([s.build(2),s.build(2)]);assert.equal(r[0].id,r[1].id);assert.equal(s.snapshot().packages.length,1);});
test('replacing source stales preserved ZIP; rebuilding creates a new receipt',async()=>{const s=ready(),r=await s.build(2),old=s.packageBytes(r.id);s.attach('brief','brief.txt',bytes('Updated'),2);assert.equal(s.receipt(r.id).status,'stale');assert.deepEqual(s.packageBytes(r.id),old);const next=await s.build(3);assert.notEqual(next.id,r.id);assert.equal(next.status,'current');});
test('identical attachment does not change revision',()=>{const s=ready();s.attach('approval','approval.txt',bytes('Synthetic approval'),2);assert.equal(s.snapshot().revision,2);});
test('stale edits and builds are rejected',async()=>{const s=ready();assert.throws(()=>s.attach('brief','x.txt',bytes('x'),1),/REVISION_CONFLICT/);await assert.rejects(s.build(1),/REVISION_CONFLICT/);});
test('reject empty, oversized, path traversal and unknown slot',()=>{const s=ready();for(const name of ['../x','a/b','a\\b','..',''])assert.throws(()=>s.attach('brief',name,bytes('x'),2),/INVALID_FILENAME/);assert.throws(()=>s.attach('brief','a',new Uint8Array(),2),/INVALID_CONTENT/);assert.throws(()=>s.attach('brief','a',new Uint8Array(2097153),2),/INVALID_CONTENT/);assert.throws(()=>s.attach('nope','a',bytes('x'),2),/UNKNOWN_DOCUMENT/);});
test('binary files retain all byte values',async()=>{const s=ready(),data=Uint8Array.from({length:256},(_,i)=>i);s.attach('budget','binary.bin',data,2);const r=await s.build(3);assert.deepEqual(unzipStore(s.packageBytes(r.id))['documents/budget/binary.bin'],data);});
test('requirements change invalidates receipt and cannot remove all requirements',async()=>{const s=ready(),r=await s.build(2);s.require('approval',false,2);assert.equal(s.receipt(r.id).status,'stale');s.require('budget',false,3);assert.throws(()=>s.require('brief',false,4),/At least one/);const next=await s.build(4);assert.equal(next.manifest.documents.length,1);});
test('source change during hashing prevents stale commit',async()=>{let resume;const barrier=new Promise(r=>resume=r);const s=new ReceiptStore({hash:async data=>{await barrier;return sha256(data);}});s.attach('approval','a.txt',bytes('x'),1);const pending=s.build(2);s.attach('brief','b.txt',bytes('y'),2);resume();await assert.rejects(pending,/REVISION_CONFLICT/);assert.equal(s.snapshot().packages.length,0);});
test('aborted operation never creates package',async()=>{const s=ready(),c=new AbortController();c.abort();await assert.rejects(s.build(2,'webmcp',c.signal),/CANCELLED/);assert.equal(s.snapshot().packages.length,0);});
test('returned values cannot modify store',async()=>{const s=ready(),r=await s.build(2);r.manifest.documents[0].name='forged';s.packageBytes(r.id).fill(0);const state=s.snapshot();state.documents[0].required=false;assert.notEqual(s.receipt(r.id).manifest.documents[0].name,'forged');assert.equal(s.packageBytes(r.id)[0],0x50);assert.equal(s.snapshot().documents[0].required,true);});
test('download request is not download confirmation',async()=>{const s=ready(),r=await s.build(2);s.downloadRequested(r.id);assert.equal(s.receipt(r.id).downloadStatus,'not_confirmed');assert.equal(s.snapshot().events.at(-1).action,'download_requested');});
test('WebMCP handler contract exercises same source state',async()=>{const s=new ReceiptStore(),tools=toolsFor(s),call=(name,args)=>tools.find(t=>t.name===name).execute(args).then(JSON.parse);assert.equal((await call('build_package',{expectedRevision:1})).ok,false);assert.equal((await call('attach_document',{id:'approval',name:'a.txt',content:'Sample',expectedRevision:1})).ok,true);const r=await call('build_package',{expectedRevision:2});assert.equal(r.ok,true);assert.equal((await call('get_receipt',{id:r.result.id})).result.status,'current');assert.equal((await call('attach_document',{id:'approval',name:'a',content:7,expectedRevision:2})).ok,false);});
test('registration detects missing API and handles partial failure',async()=>{assert.equal((await registerWebMCP(undefined,ready())).status,'unavailable');let count=0,signal;const r=await registerWebMCP({registerTool:async(t,o)=>{signal=o.signal;if(++count===2)throw new Error('denied');}},ready());assert.equal(r.status,'error');assert.equal(signal.aborted,true);});
test('registration publishes exactly four tool definitions to a mock API',async()=>{const names=[];const r=await registerWebMCP({registerTool:async t=>names.push(t.name)},ready());assert.equal(r.status,'registered');assert.deepEqual(names,['get_case','attach_document','build_package','get_receipt']);r.dispose();});
test('independent Python zipfile verifies ZIP structure, CRC and manifest hashes',async()=>{
  const s=ready(),r=await s.build(2);
  const result=spawnSync('python3',['-c',`import sys,io,zipfile,json,hashlib
z=zipfile.ZipFile(io.BytesIO(sys.stdin.buffer.read()))
assert z.testzip() is None
m=json.loads(z.read('manifest.json'))
assert len(z.namelist()) == len(m['documents'])+1
for d in m['documents']:
 b=z.read(d['path'])
 assert len(b)==d['bytes']
 assert hashlib.sha256(b).hexdigest()==d['sha256']
print('independent ZIP verification passed')`],{input:s.packageBytes(r.id)});
  assert.equal(result.status,0,result.stderr.toString());
});
